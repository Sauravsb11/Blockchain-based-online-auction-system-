# BlockChain Term Project

Smart Contract for a Decentralized Auction like an eBay alternative. Using the blockchain's properties to perform auctions. ICO launched on ERC20 token named as
SalCoin (SAL). Transaction Hash of ERC20 = 0x8bba883211abec377aabadd69cf13d31385fe62ce145f31bc36723554b270a1e
Transaction hash of ICO = 0xb5316c032a8b8e75c1298501eeabd0a7a1ecc4e22029e4241acd7c37c253a40b
